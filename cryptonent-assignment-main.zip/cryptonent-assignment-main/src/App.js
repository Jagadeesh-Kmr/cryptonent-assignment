import './App.css'

import GithubPopularRepos from './components/GithubPopularRepos'

const App = () => <GithubPopularRepos />

export default App
